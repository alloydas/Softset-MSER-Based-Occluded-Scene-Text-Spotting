
149 burdwan images - v2 data1
==============================

This dataset was exported via roboflow.ai on July 1, 2022 at 5:31 AM GMT

It includes 334 images.
Words are annotated in Scaled-YOLOv4 format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


